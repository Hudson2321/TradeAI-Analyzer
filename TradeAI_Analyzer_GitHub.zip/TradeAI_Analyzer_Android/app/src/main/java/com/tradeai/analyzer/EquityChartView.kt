package com.tradeai.analyzer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max
import kotlin.math.min

class EquityChartView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var values: List<Double> = emptyList()

    fun setValues(v: List<Double>) {
        values = v
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFF171B22.toInt())
        if (values.size < 2) return
        val pad = 28f
        val w = width - pad * 2
        val h = height - pad * 2
        val lo = values.minOrNull() ?: return
        val hi = values.maxOrNull() ?: return
        val range = max(hi - lo, 0.0000001)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = 0xFF64D17B.toInt()
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = pad + w * i / (values.size - 1)
            val y = pad + h * (1f - ((v - lo) / range).toFloat())
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, paint)
    }
}
