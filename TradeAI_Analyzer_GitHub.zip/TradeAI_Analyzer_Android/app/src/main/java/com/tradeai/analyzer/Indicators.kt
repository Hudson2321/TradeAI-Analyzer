package com.tradeai.analyzer

import kotlin.math.abs

object Indicators {

    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val out = MutableList(values.size) { Double.NaN }
        if (values.size < period) return out
        var sum = 0.0
        for (i in 0 until period) sum += values[i]
        var prev = sum / period
        out[period - 1] = prev
        val k = 2.0 / (period + 1)
        for (i in period until values.size) {
            prev = values[i] * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    fun rsi(values: List<Double>, period: Int = 14): List<Double> {
        val out = MutableList(values.size) { Double.NaN }
        if (values.size <= period) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = values[i] - values[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        gain /= period
        loss /= period
        out[period] = if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gain / loss)

        for (i in period + 1 until values.size) {
            val d = values[i] - values[i - 1]
            val g = if (d > 0) d else 0.0
            val l = if (d < 0) -d else 0.0
            gain = (gain * (period - 1) + g) / period
            loss = (loss * (period - 1) + l) / period
            out[i] = if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gain / loss)
        }
        return out
    }

    fun macd(values: List<Double>): Triple<List<Double>, List<Double>, List<Double>> {
        val e12 = ema(values, 12)
        val e26 = ema(values, 26)
        val line = MutableList(values.size) { Double.NaN }
        for (i in values.indices) {
            if (!e12[i].isNaN() && !e26[i].isNaN()) line[i] = e12[i] - e26[i]
        }
        val valid = line.filter { !it.isNaN() }
        val signalValid = ema(valid, 9)
        val signal = MutableList(values.size) { Double.NaN }
        var j = 0
        for (i in line.indices) {
            if (!line[i].isNaN()) {
                signal[i] = if (j < signalValid.size) signalValid[j] else Double.NaN
                j++
            }
        }
        val hist = MutableList(values.size) { Double.NaN }
        for (i in values.indices) {
            if (!line[i].isNaN() && !signal[i].isNaN()) hist[i] = line[i] - signal[i]
        }
        return Triple(line, signal, hist)
    }
}
