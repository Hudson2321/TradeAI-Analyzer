package com.tradeai.analyzer

object Strategies {

    // Returns: 1 buy, -1 sell, 0 no signal.
    fun rsiMacd(c: List<Candle>, i: Int, rsi: List<Double>, macd: List<Double>, signal: List<Double>): Int {
        if (i <= 0 || rsi[i].isNaN() || macd[i].isNaN() || signal[i].isNaN()) return 0
        val bullish = macd[i] > signal[i] && rsi[i] > 50.0
        val bearish = macd[i] < signal[i] && rsi[i] < 50.0
        return when {
            bullish -> 1
            bearish -> -1
            else -> 0
        }
    }

    fun ema921(c: List<Candle>, i: Int, e9: List<Double>, e21: List<Double>): Int {
        if (i <= 0 || e9[i].isNaN() || e21[i].isNaN() || e9[i - 1].isNaN() || e21[i - 1].isNaN()) return 0
        val bullCross = e9[i] > e21[i] && e9[i - 1] <= e21[i - 1]
        val bearCross = e9[i] < e21[i] && e9[i - 1] >= e21[i - 1]
        return when {
            bullCross -> 1
            bearCross -> -1
            else -> 0
        }
    }

    // A simple transparent scoring engine, not an AI model.
    fun tradeAi(c: List<Candle>, i: Int, rsi: List<Double>, macd: List<Double>, signal: List<Double>, e9: List<Double>, e21: List<Double>): Int {
        if (i <= 0) return 0
        var score = 0
        if (!rsi[i].isNaN()) {
            if (rsi[i] > 55) score += 1
            if (rsi[i] < 45) score -= 1
        }
        if (!macd[i].isNaN() && !signal[i].isNaN()) {
            if (macd[i] > signal[i]) score += 1
            if (macd[i] < signal[i]) score -= 1
        }
        if (!e9[i].isNaN() && !e21[i].isNaN()) {
            if (e9[i] > e21[i]) score += 1
            if (e9[i] < e21[i]) score -= 1
        }
        return when {
            score >= 2 -> 1
            score <= -2 -> -1
            else -> 0
        }
    }
}
