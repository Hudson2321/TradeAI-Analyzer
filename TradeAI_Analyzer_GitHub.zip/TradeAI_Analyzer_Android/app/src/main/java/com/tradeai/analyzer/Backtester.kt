package com.tradeai.analyzer

import kotlin.math.max

object Backtester {

    fun run(
        candles: List<Candle>,
        strategy: Strategy,
        initialCapital: Double,
        riskPct: Double = 1.0,
        rewardRisk: Double = 2.0
    ): BacktestResult {
        if (candles.size < 40) {
            return emptyResult(initialCapital)
        }

        val closes = candles.map { it.close }
        val rsi = Indicators.rsi(closes)
        val (macd, signal, _) = Indicators.macd(closes)
        val e9 = Indicators.ema(closes, 9)
        val e21 = Indicators.ema(closes, 21)

        var capital = initialCapital
        val equity = MutableList(candles.size) { initialCapital }
        val trades = mutableListOf<Trade>()
        var position = 0
        var entry = 0.0
        var entryIndex = -1
        var riskMoney = 0.0

        for (i in 40 until candles.size) {
            val sig = when (strategy) {
                Strategy.RSI_MACD -> Strategies.rsiMacd(candles, i, rsi, macd, signal)
                Strategy.EMA_9_21 -> Strategies.ema921(candles, i, e9, e21)
                Strategy.TRADE_AI -> Strategies.tradeAi(candles, i, rsi, macd, signal, e9, e21)
            }

            if (position == 0 && sig != 0) {
                position = sig
                entry = candles[i].close
                entryIndex = i
                riskMoney = capital * (riskPct / 100.0)
            } else if (position != 0 && sig == -position) {
                val exit = candles[i].close
                val movePct = if (position == 1) (exit - entry) / entry else (entry - exit) / entry
                val pnl = riskMoney * (movePct / 0.005) // 0.5% adverse move ~= 1R
                capital += pnl
                trades += Trade(entryIndex, i, position, entry, exit, pnl)
                position = 0
                entryIndex = -1
            }
            equity[i] = capital
        }

        if (position != 0 && entryIndex >= 0) {
            val exit = candles.last().close
            val movePct = if (position == 1) (exit - entry) / entry else (entry - exit) / entry
            val pnl = riskMoney * (movePct / 0.005)
            capital += pnl
            trades += Trade(entryIndex, candles.lastIndex, position, entry, exit, pnl)
            equity[candles.lastIndex] = capital
        }

        var peak = initialCapital
        var maxDd = 0.0
        for (v in equity) {
            if (v > peak) peak = v
            if (peak > 0) maxDd = max(maxDd, (peak - v) / peak * 100.0)
        }

        val wins = trades.count { it.pnl > 0 }
        val losses = trades.count { it.pnl < 0 }
        val grossProfit = trades.filter { it.pnl > 0 }.sumOf { it.pnl }
        val grossLoss = trades.filter { it.pnl < 0 }.sumOf { -it.pnl }
        val pf = if (grossLoss == 0.0) if (grossProfit > 0) Double.POSITIVE_INFINITY else 0.0 else grossProfit / grossLoss

        var maxWin = 0
        var maxLoss = 0
        var w = 0
        var l = 0
        for (t in trades) {
            if (t.pnl > 0) { w++; l = 0; maxWin = max(maxWin, w) }
            else if (t.pnl < 0) { l++; w = 0; maxLoss = max(maxLoss, l) }
        }

        return BacktestResult(
            trades = trades,
            equity = equity,
            initialCapital = initialCapital,
            finalCapital = capital,
            wins = wins,
            losses = losses,
            winRate = if (trades.isEmpty()) 0.0 else wins.toDouble() / trades.size * 100.0,
            profitLoss = capital - initialCapital,
            returnPct = if (initialCapital == 0.0) 0.0 else (capital - initialCapital) / initialCapital * 100.0,
            maxDrawdownPct = maxDd,
            profitFactor = pf,
            maxWinStreak = maxWin,
            maxLossStreak = maxLoss
        )
    }

    private fun emptyResult(initial: Double) = BacktestResult(
        emptyList(), listOf(initial), initial, initial, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0
    )
}
