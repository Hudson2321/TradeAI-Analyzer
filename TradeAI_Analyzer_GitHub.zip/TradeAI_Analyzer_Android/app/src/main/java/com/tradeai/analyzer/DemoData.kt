package com.tradeai.analyzer

import kotlin.math.sin

object DemoData {
    fun generate(n: Int = 900): List<Candle> {
        val out = ArrayList<Candle>(n)
        var price = 1.0600
        var seed = 1234567L
        fun rnd(): Double {
            seed = (seed * 1103515245L + 12345L) and 0x7fffffff
            return seed.toDouble() / 0x7fffffff.toDouble()
        }
        for (i in 0 until n) {
            val wave = sin(i / 27.0) * 0.0018 + sin(i / 71.0) * 0.0022
            val drift = if ((i / 180) % 2 == 0) 0.000015 else -0.000012
            val noise = (rnd() - 0.5) * 0.0020
            val open = price
            val close = (price + wave * 0.08 + drift + noise).coerceAtLeast(0.5)
            val high = maxOf(open, close) + rnd() * 0.0009
            val low = minOf(open, close) - rnd() * 0.0009
            out += Candle(i.toLong(), open, high, low, close)
            price = close
        }
        return out
    }
}
