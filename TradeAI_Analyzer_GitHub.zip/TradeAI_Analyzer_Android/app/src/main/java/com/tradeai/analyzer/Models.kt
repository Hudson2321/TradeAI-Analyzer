package com.tradeai.analyzer

data class Candle(
    val time: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double
)

enum class Strategy {
    RSI_MACD, EMA_9_21, TRADE_AI
}

data class Trade(
    val entryIndex: Int,
    val exitIndex: Int,
    val direction: Int, // 1 long, -1 short
    val entry: Double,
    val exit: Double,
    val pnl: Double
)

data class BacktestResult(
    val trades: List<Trade>,
    val equity: List<Double>,
    val initialCapital: Double,
    val finalCapital: Double,
    val wins: Int,
    val losses: Int,
    val winRate: Double,
    val profitLoss: Double,
    val returnPct: Double,
    val maxDrawdownPct: Double,
    val profitFactor: Double,
    val maxWinStreak: Int,
    val maxLossStreak: Int
)
