package com.tradeai.analyzer

import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader

object CsvLoader {
    fun load(context: Context, uri: Uri): List<Candle> {
        val result = mutableListOf<Candle>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            BufferedReader(InputStreamReader(input)).useLines { lines ->
                var first = true
                var fallbackTime = 0L
                lines.forEach { raw ->
                    val line = raw.trim()
                    if (line.isEmpty()) return@forEach
                    if (first && line.lowercase().contains("open")) {
                        first = false
                        return@forEach
                    }
                    first = false
                    val p = line.split(",").map { it.trim() }
                    if (p.size >= 5) {
                        val time = p[0].toLongOrNull() ?: fallbackTime
                        val o = p[1].toDoubleOrNull()
                        val h = p[2].toDoubleOrNull()
                        val l = p[3].toDoubleOrNull()
                        val c = p[4].toDoubleOrNull()
                        if (o != null && h != null && l != null && c != null) {
                            result += Candle(time, o, h, l, c)
                            fallbackTime++
                        }
                    }
                }
            }
        }
        return result
    }
}
