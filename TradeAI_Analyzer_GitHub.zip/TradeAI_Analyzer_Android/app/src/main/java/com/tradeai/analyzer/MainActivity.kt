package com.tradeai.analyzer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {

    private var candles: List<Candle> = DemoData.generate()
    private lateinit var strategySpinner: Spinner
    private lateinit var capitalInput: EditText
    private lateinit var chart: EquityChartView
    private lateinit var resultText: TextView
    private lateinit var dataText: TextView

    private val strategyNames = arrayOf(
        "RSI + MACD",
        "Cruzamento EMA 9/21",
        "Motor TradeAI"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        runBacktest()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101318.toInt())
            setPadding(18, 18, 18, 18)
        }

        val title = TextView(this).apply {
            text = "TRADEAI ANALYZER"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "Backtest • RSI • MACD • EMA • análise de risco"
            textSize = 13f
            setTextColor(0xFFB8C0CC.toInt())
            setPadding(0, 4, 0, 14)
        }
        root.addView(subtitle)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF171B22.toInt())
            setPadding(14, 12, 14, 12)
        }

        val stratLabel = label("Estratégia")
        controls.addView(stratLabel)
        strategySpinner = Spinner(this)
        strategySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, strategyNames)
        controls.addView(strategySpinner)

        val capLabel = label("Capital inicial")
        controls.addView(capLabel)
        capitalInput = EditText(this).apply {
            setText("10000")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF808894.toInt())
            hint = "10000"
        }
        controls.addView(capitalInput)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val test = button("EXECUTAR BACKTEST") { runBacktest() }
        buttons.addView(test, LinearLayout.LayoutParams(0, 52, 1f))
        val import = button("IMPORTAR CSV") { pickCsv() }
        val ip = LinearLayout.LayoutParams(0, 52, 1f)
        ip.setMargins(10, 0, 0, 0)
        buttons.addView(import, ip)
        controls.addView(buttons)

        root.addView(controls, LinearLayout.LayoutParams(-1, -2))

        dataText = label("Dados: demonstração • ${candles.size} candles")
        dataText.setPadding(0, 12, 0, 8)
        root.addView(dataText)

        chart = EquityChartView(this)
        root.addView(chart, LinearLayout.LayoutParams(-1, 180))

        resultText = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFE8ECF2.toInt())
            setPadding(4, 12, 4, 4)
        }
        val scroll = ScrollView(this)
        scroll.addView(resultText)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val warning = TextView(this).apply {
            text = "⚠ Backtest não garante resultados futuros. Esta versão não envia ordens para corretoras."
            textSize = 11f
            setTextColor(0xFFFFC857.toInt())
            setPadding(4, 8, 4, 4)
        }
        root.addView(warning)

        setContentView(root)
    }

    private fun label(s: String): TextView = TextView(this).apply {
        text = s
        textSize = 13f
        setTextColor(0xFFB8C0CC.toInt())
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        }

    private fun runBacktest() {
        val capital = capitalInput.text.toString().toDoubleOrNull() ?: 10000.0
        val strategy = when (strategySpinner.selectedItemPosition) {
            1 -> Strategy.EMA_9_21
            2 -> Strategy.TRADE_AI
            else -> Strategy.RSI_MACD
        }
        val result = Backtester.run(candles, strategy, capital)
        chart.setValues(result.equity)
        val pf = if (result.profitFactor.isInfinite()) "∞" else fmt(result.profitFactor)
        resultText.text = """
            RESULTADO DO BACKTEST

            Estratégia: ${strategyNames[strategySpinner.selectedItemPosition]}
            Candles: ${candles.size}

            Operações: ${result.trades.size}
            Vencedoras: ${result.wins}
            Perdedoras: ${result.losses}
            Win rate: ${fmt(result.winRate)}%

            P/L: ${money(result.profitLoss)}
            Retorno: ${fmt(result.returnPct)}%
            Drawdown máximo: ${fmt(result.maxDrawdownPct)}%
            Profit Factor: $pf

            Melhor sequência de ganhos: ${result.maxWinStreak}
            Maior sequência de perdas: ${result.maxLossStreak}

            Capital final: ${money(result.finalCapital)}

            Interpretação:
            • Win rate sozinho não determina a qualidade da estratégia.
            • Drawdown e Profit Factor devem ser analisados junto com o número de operações.
            • Compare períodos diferentes antes de considerar qualquer estratégia robusta.
        """.trimIndent()
    }

    private fun pickCsv() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "text/csv"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Android callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val loaded = CsvLoader.load(this, uri)
            if (loaded.size >= 40) {
                candles = loaded.sortedBy { it.time }
                dataText.text = "Dados: CSV importado • ${candles.size} candles"
                runBacktest()
                Toast.makeText(this, "CSV importado com sucesso.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "CSV inválido ou com menos de 40 candles.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun fmt(v: Double): String = String.format(Locale.US, "%.2f", v)
    private fun money(v: Double): String = "$" + String.format(Locale.US, "%,.2f", v)
}
