# TradeAI Analyzer — Android

Aplicativo Android offline para backtest e análise de estratégias.

## O que esta versão já possui

- RSI + MACD
- Cruzamento EMA 9/21
- Motor TradeAI (pontuação combinada)
- Backtest com capital inicial configurável
- Timeframes M1/M5/M15/M30/H1/H4/D1
- Janela de 30/90/180/365 dias ou todos os candles importados
- Métricas: operações, ganhos, perdas, win rate, P/L, retorno %, drawdown máximo, profit factor, sequência máxima de perdas/ganhos e capital final
- Gráfico de evolução do capital
- Importação de CSV OHLC
- Dados de demonstração embutidos para testar o aplicativo imediatamente
- Não depende de API, corretora ou serviço de IA nesta primeira versão

## Formato CSV

Cabeçalho recomendado:

timestamp,open,high,low,close

O timestamp pode ser um número (epoch em segundos/milisegundos) ou texto; nesta versão o primeiro campo é apenas preservado para identificação. As colunas OHLC precisam estar nessa ordem.

Exemplo:

timestamp,open,high,low,close
1,1.0600,1.0650,1.0580,1.0630
2,1.0630,1.0670,1.0610,1.0660

## Como gerar o APK

1. Instale Android Studio em um computador.
2. Abra a pasta `TradeAI_Analyzer_Android`.
3. Aguarde o Gradle sincronizar.
4. Use Build > Build APK(s).
5. O APK de debug será gerado em:
   `app/build/outputs/apk/debug/app-debug.apk`

## Pelo celular

Para compilar diretamente no Android, use um ambiente Android compatível com Gradle/SDK. A maneira mais simples para iniciantes é abrir o projeto no Android Studio em um computador.

## Importante

Os resultados de backtest não garantem resultados futuros. Esta versão é uma ferramenta de análise e não envia ordens para uma corretora.
